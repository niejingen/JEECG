package com.jeecg.demo.page;

import java.util.List;

import com.jeecg.demo.entity.JformOrderCustomerEntity;

/**
 * 订单客户信息 行编辑用到
 */
public class JformOrderCustomerPage {
	  private List<JformOrderCustomerEntity> demos;

	public List<JformOrderCustomerEntity> getDemos() {
		return demos;
	}

	public void setDemos(List<JformOrderCustomerEntity> demos) {
		this.demos = demos;
	}
	  
	  

}
