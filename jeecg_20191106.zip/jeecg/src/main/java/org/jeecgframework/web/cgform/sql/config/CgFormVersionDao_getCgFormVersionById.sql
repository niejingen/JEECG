select 
jform_version 
from cgform_head  
where id = :id